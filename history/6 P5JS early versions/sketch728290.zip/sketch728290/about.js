/*
This is a remaking and remastering of Crosser, a product of SWEAT from the year 2000

in the code we will focus on clarity of code over optimization available through abstractions

the earliest versions of this remake are being created within OpenProcessing.org, 
using P5JS, a project initiated and led by Lauren McCarthy, 
enabling the P5Play library by Paolo Pedercini,
on an iPad Pro (2018) in Safari for iOS, and a MacBookPro (early 2019)
tested in both Safari and Chrome
it is hoped that it will run on a Raspberry Pi in Chromium 

work began in earnest on this effort mid May of 2019

ORIGINAL TEAM AND WORK
Crosser was made by
Rafael Fajardo
Francisco Ortega
Miguel Tarango
Marco Ortega
Ryan Molloy
Tomás Márquez
Carmen Escobar
in El Paso, Texas, USA and Ciudad Juarez, Chihuahua, MEX
using the Apple abandoned software Cocoa (Design Release 2 or later) for Mac OS 7.6 - 9
and was later refactored/ported in Stagecast Creator for Mac OS X
*/